<?
mysql_connect("localhost");
mysql_select_db("quiz") or die("database could not connect ");
echo "hell";
exit();
?> 
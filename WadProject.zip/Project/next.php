<?php

echo "we will add insert query code here";
?>